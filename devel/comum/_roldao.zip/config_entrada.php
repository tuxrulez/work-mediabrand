<?php
/* volume das musicas 0 - 100, com intervalo de 5 em 5 */
$volumeMusical = 90;
/* volume do comercial 0 - 100, com intervalo de 5 em 5 */
$volumeComercial = 20;


/* configura se a máquina vai receber as musicas por streaming, colocar true se for usar */
$streaming = true;

/* url do streaming */ 
$urlStream = "mms://108.163.142.77/Contemporaneo";

/* Contemporaneo */
//$urlStream = "mms://174.142.81.28/Contemporaneo1";

/* Alternativo */
//$urlStream = "mms://174.142.81.28/Contemporaneo";

/* Fitness */
//$urlStream = "mms://174.142.81.28/Fitness1";

/* Instrumental */
//$urlStream = "mms://174.142.81.28/Instrumental1";

/* Lounge */
//$urlStream = "mms://174.142.81.28/Lounge1";

/* Bossa Lounge */
//$urlStream = "mms://174.142.81.28/Bossa_Lounge1";

/* Popular */
//$urlStream = "mms://174.142.81.28/Popular1";

?>
