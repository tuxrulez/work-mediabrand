#!/usr/bin/php -q
<?php
include "config_entrada.php";

$volume = 0;

while ($volume < $volumeMusical) {
	$volume = $volume + 5;
	
	$comando = "amixer set Line ".$volume."%";
	exec($comando);

	usleep(50000);
}
?>