#!/usr/bin/php -q
<?php

$volume = 100;

for ($i=0; $i < 10; $i++) 
{ 
	$volume = $volume - 10;

	$comando = "amixer set Line ".$volume."%";

	exec($comando);

	usleep(100000);
}
?>