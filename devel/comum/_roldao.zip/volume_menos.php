#!/usr/bin/php -q
<?php

$volume = 100;

for ($i=0; $i < 10; $i++) 
{ 
	$volume = $volume - 10;

	$cmd = "echo 'set_property volume ".$volume."' > /tmp/stream_in";
	exec($cmd);

	usleep(10000);
}

?>
