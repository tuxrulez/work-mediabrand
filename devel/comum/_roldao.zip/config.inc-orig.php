<?php
$rede = 'roldao';
$loja = 'zzz';
?>
