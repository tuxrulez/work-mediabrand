<?php
$redirect = "/locucao";
 
 header("location:$redirect");
?>