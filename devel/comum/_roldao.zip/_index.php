<html>
<title>XMMS-RADIO (JavaScript: Redirect)</title>
<body bgcolor="#FFFFFF">

<script language="javascript">
<!-- 

location.replace("arquivos.php");

-->
</script>

</body>
</html>
