<?php
/* VIA WEB - ALTERNATIVO */
/* $urlStream = "mms://108.163.142.77/Contemporaneo";

/* url do streaming - IP DO OUTRO RASP */ 
/* $urlStream = "http://127.0.0.1:8000/stream";

/* ---------------------------------------- */


/* OUTROS STREAMING - EM TESTE */ 

/* Contemporaneo */
//$urlStream = "mms://174.142.81.28/Contemporaneo1";

/* Fitness */
//$urlStream = "mms://174.142.81.28/Fitness1";

/* Instrumental */
//$urlStream = "mms://174.142.81.28/Instrumental1";

/* Lounge */
//$urlStream = "mms://174.142.81.28/Lounge1";

/* Bossa Lounge */
//$urlStream = "mms://174.142.81.28/Bossa_Lounge1";

/* Popular */
//$urlStream = "mms://174.142.81.28/Popular1";


/* volume do streaming 0 - 100, com intervalo de 5 em 5 */
$volumeStream = 40;
/* volume do comercial 0 - 100, com intervalo de 5 em 5 */
$volumeComercial = 50;
?>
